package com.lnt.hr.controllers;

import org.springframework.stereotype.Controller;

@Controller
public class StatusController 
{
	

}

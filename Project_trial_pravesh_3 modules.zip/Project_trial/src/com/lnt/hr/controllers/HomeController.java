package com.lnt.hr.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

// http://localhost:8082/Project_trial/app/home

@Controller
public class HomeController 
{
	@RequestMapping("/home")
	public String directHomePage() {
		return "Home";
	}

}

package com.lnt.hr.controllers;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.lnt.hr.entities.InstituteRegistration;
import com.lnt.hr.exception.ScholarshipException;
import com.lnt.hr.services.InstituteRegistrationService;

@Controller
public class DisplayController 
{
	@Resource
	private InstituteRegistrationService insServices;
	
	@RequestMapping("/minHome")
	public String getHomePage()
	{
		return "MinistryHome";
	}
	
	@RequestMapping("/getInsList")
	public ModelAndView getInstituteList()
	{
		ModelAndView mv=null;
		try
		{
			List<InstituteRegistration> insList= insServices.getInsList();
			System.out.println(insList);
			mv=new ModelAndView();
			mv.addObject("insList", insList);
			mv.setViewName("InstituteList");
		}
		catch(ScholarshipException e)
		{
			e.printStackTrace();
		}
		return mv;
	}
	
	@RequestMapping("/getInstList")
	public ModelAndView getInsDetails(@RequestParam("instituteCode") int code)
	{
		ModelAndView mv= new ModelAndView("InstituteDetails");
		InstituteRegistration insDetails=null;
		try
		{
			insDetails=insServices.getInsDetails(code);
			mv.addObject("insDetails", insDetails);
		}
		catch(ScholarshipException e)
		{
			e.printStackTrace();
		}
		return mv;
	}

}

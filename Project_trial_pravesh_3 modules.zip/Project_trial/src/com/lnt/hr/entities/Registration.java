package com.lnt.hr.entities;


import java.sql.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Entity
@Table(name="StudentRegistration")
public class Registration 
{
	
	  
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator ="IDSTUDENT_SEQ")
	@SequenceGenerator(name = "IDSTUDENT_SEQ", sequenceName = "seq_student", allocationSize = 1)
	@Id
	@Column(name = "STUDENTID") 
	private long studentId; 
	@Column(name="STATEOFDOMICILE")
	private String stateOfDomicile;
	@Column(name="DISTRICT")
	private String district;
	@Column(name="NAME")
	private String name;
	@Column(name="DATEOFBIRTH")
	private Date dateOfBirth;
	@Column(name="GENDER")
	private String gender;
	@Column(name="MOBILENO")
	private int mobileNo;
	@Column(name="EMAIL")
	private String email;
	@Column(name="INSTITUTECODE")
	private int instituteCode;
	@Column(name="AADHAARNUMBER")
	private int aadhaarNumber;
	@Column(name="BANKIFSC")
	private String bankIFSC;
	@Column(name="BANKACCOUNTNUMBER")
	private int bankAccountNumber; 
	@Column(name="BANKNAME")
	private String bankName;
	@Column(name="PASSWORD")
	private String password;
	public Registration() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Registration(long studentId, String stateOfDomicile, String district, String name, Date dateOfBirth,
			String gender, int mobileNo, String email, int instituteCode, int aadhaarNumber, String bankIFSC,
			int bankAccountNumber, String bankName, String password) {
		super();
		this.studentId = studentId;
		this.stateOfDomicile = stateOfDomicile;
		this.district = district;
		this.name = name;
		this.dateOfBirth = dateOfBirth;
		this.gender = gender;
		this.mobileNo = mobileNo;
		this.email = email;
		this.instituteCode = instituteCode;
		this.aadhaarNumber = aadhaarNumber;
		this.bankIFSC = bankIFSC;
		this.bankAccountNumber = bankAccountNumber;
		this.bankName = bankName;
		this.password = password;
	}
	public long getStudentId() {
		return studentId;
	}
	public void setStudentId(long studentId) {
		this.studentId = studentId;
	}
	public String getStateOfDomicile() {
		return stateOfDomicile;
	}
	public void setStateOfDomicile(String stateOfDomicile) {
		this.stateOfDomicile = stateOfDomicile;
	}
	public String getDistrict() {
		return district;
	}
	public void setDistrict(String district) {
		this.district = district;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Date getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(int mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getInstituteCode() {
		return instituteCode;
	}
	public void setInstituteCode(int instituteCode) {
		this.instituteCode = instituteCode;
	}
	public int getAadhaarNumber() {
		return aadhaarNumber;
	}
	public void setAadhaarNumber(int aadhaarNumber) {
		this.aadhaarNumber = aadhaarNumber;
	}
	public String getBankIFSC() {
		return bankIFSC;
	}
	public void setBankIFSC(String bankIFSC) {
		this.bankIFSC = bankIFSC;
	}
	public int getBankAccountNumber() {
		return bankAccountNumber;
	}
	public void setBankAccountNumber(int bankAccountNumber) {
		this.bankAccountNumber = bankAccountNumber;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public String toString() {
		return "Registration [studentId=" + studentId + ", stateOfDomicile=" + stateOfDomicile + ", district="
				+ district + ", name=" + name + ", dateOfBirth=" + dateOfBirth + ", gender=" + gender + ", mobileNo="
				+ mobileNo + ", email=" + email + ", instituteCode=" + instituteCode + ", aadhaarNumber="
				+ aadhaarNumber + ", bankIFSC=" + bankIFSC + ", bankAccountNumber=" + bankAccountNumber + ", bankName="
				+ bankName + ", password=" + password + "]";
	}
	
	
	
/*	
	@OneToOne(cascade = CascadeType.ALL)
	@PrimaryKeyJoinColumn
	private Login login;*/




	
	
	
	
		

}

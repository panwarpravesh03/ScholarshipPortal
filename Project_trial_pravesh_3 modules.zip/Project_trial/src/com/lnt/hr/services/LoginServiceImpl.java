package com.lnt.hr.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.lnt.hr.daos.LoginDao;
import com.lnt.hr.entities.Login;
import com.lnt.hr.exception.LoginException;

@Service
public class LoginServiceImpl implements LoginService
{
	@Autowired
	LoginDao loginDao;

	public Login insertNewStudent(Login login) throws LoginException 
	{
		return loginDao.insertNewStudent(login);
	}


}
package com.lnt.hr.daos;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.lnt.hr.entities.Registration;
import com.lnt.hr.exception.RegistrationException;

@Repository
@Transactional(propagation= Propagation.REQUIRED)
public class RegistrationDaoImpl implements RegistrationDao 
{
	@PersistenceContext
	private EntityManager entityManager;

	
	


	@Override
	public Registration insertNewStudent(Registration registration) throws RegistrationException 
	{
		entityManager.persist(registration);
		return registration;
	}

}

package com.lnt.hr.daos;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.lnt.hr.entities.InstituteRegistration;
import com.lnt.hr.exception.ScholarshipException;

@Repository
@Transactional(propagation= Propagation.REQUIRED)
public class InstituteRegistrationDaoImpl implements InstituteRegistrationDao
{	
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public InstituteRegistration insertNewInstitute(InstituteRegistration instituteRegistration) throws ScholarshipException 
	{
		entityManager.persist(instituteRegistration);
		return instituteRegistration;
	}

	@Override
	public List<InstituteRegistration> getInsList() 
	{
		Query qry=entityManager.createNamedQuery("allInstitute");

		return qry.getResultList();
	}

	@Override
	public InstituteRegistration getInsDetails(int instituteCode) throws ScholarshipException 
	{
		InstituteRegistration insDetails=entityManager.find(InstituteRegistration.class,instituteCode);
		return insDetails;
	}
	
	
	
	
	

}

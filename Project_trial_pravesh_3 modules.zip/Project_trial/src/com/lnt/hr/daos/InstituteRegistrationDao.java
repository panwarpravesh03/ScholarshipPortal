package com.lnt.hr.daos;

import java.util.List;

import com.lnt.hr.entities.InstituteRegistration;
import com.lnt.hr.exception.ScholarshipException;

public interface InstituteRegistrationDao 
{
	public InstituteRegistration insertNewInstitute(InstituteRegistration instituteRegistration) throws ScholarshipException;
	
	public List<InstituteRegistration> getInsList() throws ScholarshipException;
	
	public InstituteRegistration getInsDetails(int instituteCode) throws ScholarshipException;

}

package com.lnt.hr.eligibility;

import org.springframework.stereotype.Service;

import com.lnt.hr.entities.Scholarship;

@Service("Pragati")
public class Pragati implements CheckEligibility
{

	@Override
	public String checkEligibility(Scholarship scholarship) 
	{
		return "false";
		
		
	}

}

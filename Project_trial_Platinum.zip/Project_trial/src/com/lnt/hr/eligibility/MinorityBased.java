package com.lnt.hr.eligibility;

import org.springframework.stereotype.Service;

import com.lnt.hr.entities.Scholarship;

@Service("MinorityBased")
public class MinorityBased implements CheckEligibility
{

	@Override
	public String checkEligibility(Scholarship scholarship) 
	{
		int tenthPercentage = scholarship.getTenthPercentObtained();
		int twelthPercentage =scholarship.getTwelthPercentObtained();
		
		if()
		
		return null;
	}

}

package com.lnt.hr.eligibility;

import org.springframework.stereotype.Service;

import com.lnt.hr.entities.Scholarship;

@Service("MeritBased")
public class MeritBased implements CheckEligibility
{
	@Override
	public String checkEligibility(Scholarship scholarship) 
	{
		String community=scholarship.getCommunity();
		int percentage=scholarship.getTenthPercentObtained();
		System.out.println(scholarship.getCommunity());
		System.out.println(scholarship.getTenthPercentObtained());
		
		if(((community.equals("SC") || community.equals("ST")) && (percentage>=55)))
		{
			//System.out.println("test  1");
			return "true";
		}
		else if(community.equals("General") && percentage>= 60)
		{
			//System.out.println("test  2");
			return "true";
		}
		else
		{
			//System.out.println("test  3");
			return "false";
		}
		
	}

}





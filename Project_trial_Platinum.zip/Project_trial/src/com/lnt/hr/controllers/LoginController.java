package com.lnt.hr.controllers;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.lnt.hr.entities.Login;
import com.lnt.hr.exception.LoginException;
import com.lnt.hr.services.LoginService;
import com.lnt.hr.services.LoginServiceImpl;

@Controller
public class LoginController 
{
	@Resource
	private LoginService loginServices = new LoginServiceImpl();
	
	@RequestMapping("/showLoginForm")
	public ModelAndView showLoginForm() {
		ModelAndView mv = new ModelAndView("loginForm");
		Login login = new Login();
		mv.addObject("login", login);
		return mv;
	}
	
	
	
	@RequestMapping("/submitForm1")
	public ModelAndView NewStudentJoined(@Valid @ModelAttribute("login") Login login, BindingResult br,
			HttpServletRequest request) {

		ModelAndView mv = new ModelAndView("studentRegPage");
		
			try 
			{
				login = loginServices.insertNewStudent(login);
			} catch (LoginException e) {
				e.printStackTrace();
			}
			int loginID=login.getAadhaarNumber();
			mv.addObject("loginID", loginID);
			return mv;
		}
	
	@RequestMapping("/submitForm2")
	public String loginSuccess()
	{
		return "loginSuccess";
	}

}

package com.lnt.hr.controllers;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class FileDisplayController {
	
    @Autowired
	ServletContext context;
    
    @RequestMapping("/displayPdf/{applicationId}/{fileName}")
    public void displayPdf(HttpServletRequest request, HttpServletResponse response, @PathVariable("fileName") String fileName, @PathVariable("applicationId") String applicationId) {
        File file = new File("D:\\projectGladiator\\.metadata\\.plugins\\org.eclipse.wst.server.core\\tmp1\\wtpwebapps\\Project_trial\\Uploaded Documents\\" 
        						 + applicationId + "_" + fileName + ".pdf");
        response.setHeader("Content-Type", context.getMimeType(file.getName()));
        response.setHeader("Content-Length", String.valueOf(file.length()));
        response.setHeader("Content-Disposition", "inline; filename=\"" + fileName + ".pdf\"");
        request.setAttribute("fileName", fileName);
        try 
        {
			Files.copy(file.toPath(), response.getOutputStream());
		} 
        catch (IOException e) 
        {
        	e.printStackTrace();
			//request.setAttribute("errorMessage", "Error displaying pdf.");
		}
    }
}

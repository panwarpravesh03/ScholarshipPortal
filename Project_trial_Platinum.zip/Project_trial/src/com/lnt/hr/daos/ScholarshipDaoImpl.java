package com.lnt.hr.daos;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.lnt.hr.entities.InstituteRegistration;
import com.lnt.hr.entities.Scholarship;
import com.lnt.hr.exception.RegistrationException;
import com.lnt.hr.exception.ScholarshipException;

@Repository
@Transactional(propagation= Propagation.REQUIRED)
public class ScholarshipDaoImpl implements ScholarshipDao
{
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public List<Scholarship> getStudList() throws ScholarshipException 
	{
		Query qry=entityManager.createNamedQuery("allStudent");
		return qry.getResultList();
	}

	@Override
	public Scholarship getApplDetails(int applicationId) throws ScholarshipException 
	{
		Scholarship applDetails=entityManager.find(Scholarship.class,applicationId);
		return applDetails;
	}

	@Override
	public Scholarship setApplicationStatus(Scholarship scholarship) {
		entityManager.merge(scholarship);
		return scholarship;
	}

	@Override
	public Scholarship insertNewScholarship(Scholarship scholarship) throws ScholarshipException 
	{
		entityManager.persist(scholarship);
		return scholarship;
	}

	



}

package com.lnt.hr.daos;

import java.util.List;

import com.lnt.hr.entities.InstituteRegistration;
import com.lnt.hr.entities.Scholarship;
import com.lnt.hr.exception.RegistrationException;
import com.lnt.hr.exception.ScholarshipException;

public interface ScholarshipDao 
{
	public List<Scholarship> getStudList() throws ScholarshipException;
	public Scholarship getApplDetails(int applicationId) throws ScholarshipException; 
	public Scholarship setApplicationStatus(Scholarship scholarship);
	public Scholarship insertNewScholarship(Scholarship scholarship) throws ScholarshipException;
	
}



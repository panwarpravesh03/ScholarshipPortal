package com.lnt.hr.daos;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.lnt.hr.entities.Login;
import com.lnt.hr.exception.LoginException;

@Repository
@Transactional(propagation= Propagation.REQUIRED)
public class LoginDaoImpl implements LoginDao
{
	
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public Login insertNewStudent(Login login) throws LoginException 
	{
		entityManager.persist(login);
		return login;
	}
	

}

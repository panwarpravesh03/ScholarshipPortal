package com.lnt.hr.services;

import java.util.List;

import com.lnt.hr.entities.Scholarship;
import com.lnt.hr.exception.RegistrationException;
import com.lnt.hr.exception.ScholarshipException;

public interface ScholarshipService 
{
	//public ScholarshipDao updatScholarshipStatus(ScholarshipDao scholarshipStatus);

	public List<Scholarship> getStudList() throws ScholarshipException;

	public Scholarship getApplDetails(int applicationId)  throws ScholarshipException; 
	public Scholarship setApplicationStatus(Scholarship scholarship)  throws ScholarshipException; 
	public Scholarship insertNewScholarship(Scholarship scholarship) throws ScholarshipException;


}

package com.lnt.hr.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Entity
@Table(name="login")
public class Login 
{
	@Id
	@Column(name="AADHAARNUMBER")
	private int aadhaarNumber;
	@Column(name="PASSWORD")
	private String password;
	
	public Login() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Login(int aadhaarNumber, String password) {
		super();
		this.aadhaarNumber = aadhaarNumber;
		this.password = password;
	}
	public int getAadhaarNumber() {
		return aadhaarNumber;
	}
	public void setAadhaarNumber(int aadhaarNumber) {
		this.aadhaarNumber = aadhaarNumber;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public String toString() {
		return "Login [aadhaarNumber=" + aadhaarNumber + ", password=" + password + "]";
	}
	
	
	
	
}	
package com.lnt.hr.entities;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.springframework.web.multipart.MultipartFile;


@NamedQueries( { @NamedQuery(name="allInstitute",query="from InstituteRegistration")


})
@Entity
@Table(name="INSTITUTEREGISTRATION")
public class InstituteRegistration {
	
	@Column(name="INSTITUTECATEGORY")
	private String instituteCategory;
	
	@Column(name="INSTITUTENAME")
	private String instituteName;
	
	@Column(name="STATE")
	private String state;
	
	@Column(name="DISTRICT")
	private String district;
	
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "IDINSTITUTE_SEQ")
	@SequenceGenerator(name = "IDINSTITUTE_SEQ", sequenceName = "seq_institute", allocationSize = 1)
	@Id
	@Column(name="INSTITUTECODE")
	private int instituteCode;
	
	@Column(name="LOCATION")
	private String location;
	
	@Column(name="TYPE")
	private String type;
	
	@Column(name="AFF")
	private String aff;
	
	@Column(name="AFFUNINAME")
	private String affUniName; 
	
	@Column(name="YEARFROMADMISSIONSTARTED")
	private Date yearFromAdmissionStarted;
	
	@Column(name = "PASSWORD")
	private String password;
	
	@Column(name="ADDRESS")
	private String address;
	
	@Column(name="PRINCIPALNAME")
	private String principalName;
	
	@Column(name="PRINCIPALMOBILENUMBER")
	private int principalMobileNumber;
	
	@Transient
	MultipartFile file;
	
	

	public String getInstituteCategory() {
		return instituteCategory;
	}

	public void setInstituteCategory(String instituteCategory) {
		this.instituteCategory = instituteCategory;
	}

	public String getInstituteName() {
		return instituteName;
	}

	public void setInstituteName(String instituteName) {
		this.instituteName = instituteName;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public int getInstituteCode() {
		return instituteCode;
	}

	public void setInstituteCode(int instituteCode) {
		this.instituteCode = instituteCode;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getAff() {
		return aff;
	}

	public void setAff(String aff) {
		this.aff = aff;
	}

	public String getAffUniName() {
		return affUniName;
	}

	public void setAffUniName(String affUniName) {
		this.affUniName = affUniName;
	}

	public Date getYearFromAdmissionStarted() {
		return yearFromAdmissionStarted;
	}

	public void setYearFromAdmissionStarted(Date yearFromAdmissionStarted) {
		this.yearFromAdmissionStarted = yearFromAdmissionStarted;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPrincipalName() {
		return principalName;
	}

	public void setPrincipalName(String principalName) {
		this.principalName = principalName;
	}

	public int getPrincipalMobileNumber() {
		return principalMobileNumber;
	}

	public void setPrincipalMobileNumber(int principalMobileNumber) {
		this.principalMobileNumber = principalMobileNumber;
	}
	
	

	public MultipartFile getFile() {
		return file;
	}

	public void setFile(MultipartFile file) {
		this.file = file;
	}

	@Override
	public String toString() {
		return "InstituteRegistration [instituteCategory=" + instituteCategory + ", instituteName=" + instituteName
				+ ", state=" + state + ", district=" + district + ", instituteCode=" + instituteCode + ", location="
				+ location + ", type=" + type + ", aff=" + aff + ", affUniName=" + affUniName
				+ ", yearFromAdmissionStarted=" + yearFromAdmissionStarted + ", password=" + password + ", address="
				+ address + ", principalName=" + principalName + ", principalMobileNumber=" + principalMobileNumber
				+ "]";
	}

	public InstituteRegistration(String instituteCategory, String instituteName, String state, String district,
			int instituteCode, String location, String type, String aff, String affUniName,
			Date yearFromAdmissionStarted, String password, String address, String principalName,
			int principalMobileNumber) {
		super();
		this.instituteCategory = instituteCategory;
		this.instituteName = instituteName;
		this.state = state;
		this.district = district;
		this.instituteCode = instituteCode;
		this.location = location;
		this.type = type;
		this.aff = aff;
		this.affUniName = affUniName;
		this.yearFromAdmissionStarted = yearFromAdmissionStarted;
		this.password = password;
		this.address = address;
		this.principalName = principalName;
		this.principalMobileNumber = principalMobileNumber;
	}

	public InstituteRegistration() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	

	

	
	
	

}

